﻿using Microsoft.EntityFrameworkCore;
using MvcMovie.Data;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace MvcMovie.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcMovieContext(serviceProvider.GetRequiredService<DbContextOptions<MvcMovieContext>>()))
            {
                //Look for any movies
                if (context == null) {
                    return; //DB has been selected  
                }
                context.Movie.AddRange(
                    new Movie
                    {
                        Title = "When harry met Sajal",
                        ReleaseDate = DateTime.Parse("1999-2-12"),
                        Genre = "Romantic Comedy",
                        Price = 7.99M
                    },
                     new Movie
                     {
                         Title = "Tere naam",
                         ReleaseDate = DateTime.Parse("2000-1-1"),
                         Genre = "Romantic Tragedy",
                         Price = 8.99M
                     },
                      new Movie
                      {
                          Title = "Kajal",
                          ReleaseDate = DateTime.Parse("2003-9-2"),
                          Genre = "Slice of life",
                          Price = 3.88M
                      }
                    );
                context.SaveChanges();
            }
        }
    }
}
